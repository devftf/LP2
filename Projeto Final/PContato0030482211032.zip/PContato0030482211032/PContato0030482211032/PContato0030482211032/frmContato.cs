﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PContato0030482211032

{
    public partial class frmContato : Form


    {
        private BindingSource bnContato = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsCidade = new DataSet();
        private DataSet dsContato = new DataSet();
        public frmContato()
        {
            InitializeComponent();
        }

        private void FrmContato_Load(object sender, EventArgs e)
        {
            try
            {
                Contato Con = new Contato();
                dsContato.Tables.Add(Con.Listar());
                bnContato.DataSource = dsContato.Tables["Contato"];
                dgvContato.DataSource = bnContato;
                bnvContato.BindingSource = bnContato;

                txtIdContato.DataBindings.Add("TEXT", bnContato, "id_Contato");
                txtNomeContato.DataBindings.Add("TEXT", bnContato, "nome_Contato");
                txtEndereco.DataBindings.Add("TEXT", bnContato, "end_Contato");
                txtTelefone.DataBindings.Add("TEXT", bnContato, "cel_Contato");
                txtEmail.DataBindings.Add("TEXT", bnContato, "email_Contato");
                dtpDataCadastro.DataBindings.Add("TEXT", bnContato, "dtcadastro_Contato");

                Cidade Cid = new Cidade();
                dsCidade.Tables.Add(Cid.Listar());
                cbxCidade.DataSource = dsCidade.Tables["Cidade"];

                //CAMPO QUE SERÁ MOSTRADO PARA O USUÁRIO
                cbxCidade.DisplayMember = "nome_cidade";

                //CAMPO QUE É A CHAVE DA TABELA CIDADE E QUE LIGA COM A TABELA DE ALUNO
                cbxCidade.ValueMember = "id_cidade";

                //No momento de linkar os componentes com o Binding Source linkar
                cbxCidade.DataBindings.Add("SelectedValue", bnContato, "cidade_id_cidade");
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao listar Contatos!");
            }

        }

        private void BtnNovo_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
            {
                tbContato.SelectTab(1); //detalhes
            }

            bnContato.AddNew();

            txtNomeContato.Enabled = true;
            cbxCidade.Enabled = true;
            cbxCidade.SelectedIndex = 0;
            txtEndereco.Enabled = true;
            txtEmail.Enabled = true;
            txtTelefone.Enabled = true;
            dtpDataCadastro.Enabled = true;


            btnNovo.Enabled = false;
            btnAlterar.Enabled = false;
            btnExcluir.Enabled = false;
            btnSalvar.Enabled = true;
            btnCancelar.Enabled = true;

            bInclusao = true;
        }

        private void BtnSalvar_Click(object sender, EventArgs e)
        {
            if (txtNomeContato.Text == "" || txtNomeContato.Text.Length < 3)
            {
                MessageBox.Show("Nome contato inválido!");
            }
            else
            {
                Contato RegCon = new Contato();

                RegCon.Nomecontato = txtNomeContato.Text;
                RegCon.Dtcadastrocontato = Convert.ToDateTime(dtpDataCadastro.Text);
                RegCon.Cidadeodcidade = Convert.ToInt32(cbxCidade.SelectedValue.ToString());
                RegCon.Celcontato = txtTelefone.Text;
                RegCon.Emailcontato = txtEmail.Text;
                RegCon.Endcontato = txtEndereco.Text;


                if (bInclusao)
                {
                    if (RegCon.Salvar() > 0)
                    {
                        MessageBox.Show("Contato adicionado com sucesso!", "SUCESSO");

                        txtNomeContato.Enabled = false;
                        cbxCidade.Enabled = false;
                        btnNovo.Enabled = true;
                        btnAlterar.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnSalvar.Enabled = false;
                        btnCancelar.Enabled = false;

                        bInclusao = false;

                        //recarrega o grid
                        dsContato.Tables.Clear();
                        dsContato.Tables.Add(RegCon.Listar());
                        bnContato.DataSource = dsContato.Tables["Contato"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar contato", "ERRO");
                    }
                }

                else
                {
                    RegCon.Idcontato = Convert.ToInt32(txtIdContato.Text);

                    if (RegCon.Alterar() > 0)
                    {



                        MessageBox.Show("Contato alterado com sucesso");

                        dsCidade.Tables.Clear();
                        dsCidade.Tables.Add(RegCon.Listar());
                        txtIdContato.Enabled = false;
                        txtNomeContato.Enabled = false;
                        cbxCidade.Enabled = false;
                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovo.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;

                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar contato");
                    }
                }
            }
        }

        private void BtnAlterar_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
            {
                tbContato.SelectTab(1);
            }
            txtNomeContato.Enabled = true;
            cbxCidade.Enabled = true;
            txtEmail.Enabled = true;
            txtEndereco.Enabled = true;
            txtTelefone.Enabled = true;
            txtNomeContato.Focus();
            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovo.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = false;

        }

        private void BtnExcluir_Click(object sender, EventArgs e)
        {
            if (tbContato.SelectedIndex == 0)
            {
                tbContato.SelectTab(1);
            }
            if (MessageBox.Show("Confirma exclusão?", "Yes or No",
           MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
           == DialogResult.Yes)
            {
                Contato RegCon = new Contato();
                RegCon.Idcontato = Convert.ToInt16(txtIdContato.Text);
                if (RegCon.Excluir() > 0)
                {
                    MessageBox.Show("Contato excluída com sucesso!");
                    Cidade R = new Cidade();
                    dsContato.Tables.Clear();
                    dsContato.Tables.Add(R.Listar());
                    bnContato.DataSource = dsContato.Tables["Contato"];
                }
                else
                {
                    MessageBox.Show("Erro ao excluir contato!");
                }
            }
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            bnContato.CancelEdit();

            btnSalvar.Enabled = false;
            btnAlterar.Enabled = true;
            btnNovo.Enabled = true;
            btnExcluir.Enabled = true;
            btnCancelar.Enabled = false;

            txtNomeContato.Enabled = false;
            cbxCidade.Enabled = false;
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
