﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using System.Windows.Forms;

namespace PNotas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        char[] respAluno = new char[9];
        char[] gabaritoQuestoes = new char[9];
        int i, saida;
        string aux, j, questoes;
 

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            
                aux = Interaction.InputBox("Digite a alternativa escolhida", "Entrada de dados");
                if(!Char.TryParse(aux, out respAluno[j]))
                {
                    MessageBox.Show("Dado inválido");
                    j--;
                }
                else
                {
                    saida = respAluno[j] + "\n" + saida;
                }
                    for(var i=0; i<2; i++)
                        
                        aux = Interaction.InputBox("Digite a reposta " + (j) + " do aluno " + (i+1), "Entrada de respostas");
             
                        if(respAluno[i,j] =="" && gabaritoQuestoes[i,j] ==""))
                        {
                            MessageBox.Show("Resposta inválida");
                            j--;
                        }
                    
                }
                MessageBox.Show("O aluno " + (i+1) + "respondeu a questão " + (j));

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
