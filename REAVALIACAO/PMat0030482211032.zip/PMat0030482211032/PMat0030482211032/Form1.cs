﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMat0030482211032
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click_1(object sender, EventArgs e)
        {
            int[] vetorA = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            int[] vetorB = new int[10];

            for (int i = 0; i < vetorA.Length; i++)
            {
                if (i % 2 == 0)
                {
                    vetorB[i] = vetorA[i] * 5;
                }
                else
                {
                    vetorB[i] = vetorA[i] + 5;
                }
            }

            for (int i = 0; i < vetorA.Length; i++)
            {
                listBox2.Items.Add("Vetor A[" + i + "]: " + vetorA[i]);
                listBox2.Items.Add("Vetor B[" + i + "]: " + vetorB[i]);
                listBox2.Items.Add("------------------------");
            }
        }

        private void ListBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }
    }

       
    }
    

