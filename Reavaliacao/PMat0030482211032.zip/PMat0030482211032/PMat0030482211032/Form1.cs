﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;
using System.Xml.Linq;

namespace Reavalicao
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnInformar_Click(object sender, EventArgs e)
        {
            int[] VetorA = new int[10];
            int[] VetorB = new int[10];
            for (i = 0; i < 10; i ++) {

            }
             
        
         }

          

        private void lbox_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}
