﻿namespace Reavalicao
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInformar = new System.Windows.Forms.Button();
            this.lbox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnInformar
            // 
            this.btnInformar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInformar.Location = new System.Drawing.Point(131, 116);
            this.btnInformar.Name = "btnInformar";
            this.btnInformar.Size = new System.Drawing.Size(206, 111);
            this.btnInformar.TabIndex = 0;
            this.btnInformar.Text = "Informar Valores";
            this.btnInformar.UseVisualStyleBackColor = true;
            this.btnInformar.Click += new System.EventHandler(this.btnInformar_Click);
            // 
            // lbox
            // 
            this.lbox.FormattingEnabled = true;
            this.lbox.Location = new System.Drawing.Point(473, -1);
            this.lbox.Name = "lbox";
            this.lbox.Size = new System.Drawing.Size(213, 394);
            this.lbox.TabIndex = 1;
            this.lbox.SelectedIndexChanged += new System.EventHandler(this.lbox_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(686, 385);
            this.Controls.Add(this.lbox);
            this.Controls.Add(this.btnInformar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnInformar;
        private System.Windows.Forms.ListBox lbox;
    }
}

